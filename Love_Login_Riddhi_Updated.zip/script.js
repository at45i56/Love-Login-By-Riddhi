const form = document.getElementById('login-form');
const codeInput = document.getElementById('code');
const submitBtn = document.getElementById('submit-btn');
const resultDiv = document.getElementById('result');

const secretCode = 'MyRiddhi'; // Updated secret code
const nextPageUrl = 'main.html'; // Redirect page

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const userInput = codeInput.value.trim();
    if (userInput === secretCode) {
        resultDiv.innerHTML = '<p style="color: green;">Login successful! ❤️ Wishing you lots of love & happiness! Redirecting...</p>';
        setTimeout(() => {
            window.location.href = nextPageUrl;
        }, 1500);
    } else {
        resultDiv.innerHTML = '<p style="color: red;">Incorrect code. Please try again.</p>';
    }
});