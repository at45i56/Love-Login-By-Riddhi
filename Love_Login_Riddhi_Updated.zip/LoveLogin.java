import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoveLogin {
    private static final String SECRET_CODE = "MyRiddhi";

    public static void main(String[] args) {
        JFrame frame = new JFrame("Love Login by My Riddhi");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(3, 1));

        JLabel label = new JLabel("Enter Secret Code:", SwingConstants.CENTER);
        JTextField codeInput = new JTextField();
        JButton loginButton = new JButton("Login");
        JLabel resultLabel = new JLabel("", SwingConstants.CENTER);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userInput = codeInput.getText().trim();
                if (userInput.equals(SECRET_CODE)) {
                    resultLabel.setText("Login successful! ❤️ Wishing you lots of love & happiness!");
                    resultLabel.setForeground(Color.GREEN);
                    JOptionPane.showMessageDialog(frame, "Redirecting to main page...");
                } else {
                    resultLabel.setText("Incorrect code. Please try again.");
                    resultLabel.setForeground(Color.RED);
                }
            }
        });

        frame.add(label);
        frame.add(codeInput);
        frame.add(loginButton);
        frame.add(resultLabel);

        frame.setVisible(true);
    }
}